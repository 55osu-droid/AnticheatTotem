package com.anticheat.totem.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/**
 * Enregistre le dernier instant ou un joueur a effectue une action
 * manuelle susceptible d'expliquer legitimement une reapparition
 * de totem en offhand (clic inventaire, swap main, changement hotbar).
 */
public class InteractionTracker implements Listener {

    private final Map<UUID, Long> lastManualInteraction = new ConcurrentHashMap<>();

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            lastManualInteraction.put(player.getUniqueId(), System.currentTimeMillis());
        }
    }

    @EventHandler
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        lastManualInteraction.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler
    public void onItemHeld(PlayerItemHeldEvent event) {
        lastManualInteraction.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }

    /**
     * Retourne le timestamp (ms) de la derniere interaction manuelle connue,
     * ou -1 si aucune n'a jamais ete enregistree.
     */
    public long getLastInteraction(UUID uuid) {
        return lastManualInteraction.getOrDefault(uuid, -1L);
    }

    public void clear(UUID uuid) {
        lastManualInteraction.remove(uuid);
    }
}
