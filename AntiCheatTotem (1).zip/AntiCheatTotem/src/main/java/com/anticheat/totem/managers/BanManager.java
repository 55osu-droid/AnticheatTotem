package com.anticheat.totem.managers;

import com.anticheat.totem.AntiCheatTotem;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.Date;

public class BanManager {

    private final AntiCheatTotem plugin;

    public BanManager(AntiCheatTotem plugin) {
        this.plugin = plugin;
    }

    /**
     * Bannit (ou kick, selon config) le joueur, log en console,
     * alerte le staff et diffuse un message a tout le serveur
     * nommant le joueur et le type de cheat detecte.
     */
    public void punish(Player player, String cheatType) {
        var cfg = plugin.getConfig();

        String reason = cfg.getString("ban.reason", "Cheat détecté : AutoTotem");
        boolean instantBan = cfg.getBoolean("ban.instant-ban", true);

        if (instantBan) {
            Bukkit.getBanList(BanList.Type.NAME).addBan(
                    player.getName(),
                    reason,
                    null, // ban permanent
                    "AntiCheatTotem"
            );
        }

        player.kickPlayer(ChatColor.RED + reason);

        if (cfg.getBoolean("log-to-console", true)) {
            plugin.getLogger().warning("[BAN] " + player.getName() + " -> " + cheatType
                    + " (UUID: " + player.getUniqueId() + ", IP: "
                    + (player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : "inconnue") + ")");
        }

        if (cfg.getBoolean("broadcast.enabled", true)) {
            String msg = cfg.getString("broadcast.message",
                            "&c&l[AntiCheat] &f%player% &7a été banni — &cCheat détecté: &e%cheat%")
                    .replace("%player%", player.getName())
                    .replace("%cheat%", cheatType);

            String colored = ChatColor.translateAlternateColorCodes('&', msg);
            Bukkit.broadcastMessage(colored);

            String soundName = cfg.getString("broadcast.sound", "");
            if (soundName != null && !soundName.isEmpty()) {
                try {
                    Sound sound = Sound.valueOf(soundName);
                    for (Player online : Bukkit.getOnlinePlayers()) {
                        online.playSound(online.getLocation(), sound, 1.0f, 1.0f);
                    }
                } catch (IllegalArgumentException ignored) {
                    // Nom de son invalide dans la config, on ignore silencieusement
                }
            }
        }
    }

    public void alertStaff(Player cheater, int vl) {
        var cfg = plugin.getConfig();
        if (!cfg.getBoolean("staff-alert.enabled", true)) return;

        String msg = ChatColor.translateAlternateColorCodes('&',
                cfg.getString("staff-alert.message", "&8[&cAC&8] &7Violation totem pour &f%player% &7(VL: %vl%)")
                        .replace("%player%", cheater.getName())
                        .replace("%vl%", String.valueOf(vl)));

        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("anticheattotem.admin")) {
                staff.sendMessage(msg);
            }
        }
    }
}
