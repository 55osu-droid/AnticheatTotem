package com.anticheat.totem;

import com.anticheat.totem.commands.ACTotemCommand;
import com.anticheat.totem.listeners.AutoTotemListener;
import com.anticheat.totem.listeners.InteractionTracker;
import com.anticheat.totem.managers.BanManager;
import com.anticheat.totem.managers.ViolationManager;
import org.bukkit.plugin.java.JavaPlugin;

public class AntiCheatTotem extends JavaPlugin {

    private static AntiCheatTotem instance;
    private ViolationManager violationManager;
    private BanManager banManager;
    private InteractionTracker interactionTracker;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.violationManager = new ViolationManager(this);
        this.banManager = new BanManager(this);
        this.interactionTracker = new InteractionTracker();

        // Enregistrement des listeners
        getServer().getPluginManager().registerEvents(interactionTracker, this);
        getServer().getPluginManager().registerEvents(
                new AutoTotemListener(this, violationManager, banManager, interactionTracker), this);

        // Commande d'administration
        ACTotemCommand cmd = new ACTotemCommand(this, violationManager);
        getCommand("actotem").setExecutor(cmd);
        getCommand("actotem").setTabCompleter(cmd);

        getLogger().info("AntiCheatTotem active — detection auto-totem en ligne.");
    }

    @Override
    public void onDisable() {
        getLogger().info("AntiCheatTotem desactive.");
    }

    public static AntiCheatTotem getInstance() {
        return instance;
    }

    public ViolationManager getViolationManager() {
        return violationManager;
    }

    public BanManager getBanManager() {
        return banManager;
    }

    public InteractionTracker getInteractionTracker() {
        return interactionTracker;
    }
}
