package com.anticheat.totem.managers;

import com.anticheat.totem.AntiCheatTotem;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class ViolationManager {

    private final AntiCheatTotem plugin;
    private final Map<UUID, Integer> violations = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastTotemTimestamp = new ConcurrentHashMap<>();

    public ViolationManager(AntiCheatTotem plugin) {
        this.plugin = plugin;
    }

    /**
     * Ajoute une violation pour ce joueur et planifie son expiration.
     * @return le nombre total de violations actives apres ajout.
     */
    public int addViolation(UUID uuid) {
        int newValue = violations.merge(uuid, 1, Integer::sum);

        long decaySeconds = plugin.getConfig().getLong("detection.violation-decay-seconds", 300);
        new BukkitRunnable() {
            @Override
            public void run() {
                violations.computeIfPresent(uuid, (id, v) -> v > 1 ? v - 1 : null);
            }
        }.runTaskLater(plugin, decaySeconds * 20L);

        return newValue;
    }

    public int getViolations(UUID uuid) {
        return violations.getOrDefault(uuid, 0);
    }

    public void clearViolations(UUID uuid) {
        violations.remove(uuid);
    }

    public long getLastTotemTimestamp(UUID uuid) {
        return lastTotemTimestamp.getOrDefault(uuid, -1L);
    }

    public void setLastTotemTimestamp(UUID uuid, long timestamp) {
        lastTotemTimestamp.put(uuid, timestamp);
    }

    public Map<UUID, Integer> getAllViolations() {
        return violations;
    }
}
