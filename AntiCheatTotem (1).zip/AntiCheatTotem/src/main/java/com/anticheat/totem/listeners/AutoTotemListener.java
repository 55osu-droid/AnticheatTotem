package com.anticheat.totem.listeners;

import com.anticheat.totem.AntiCheatTotem;
import com.anticheat.totem.managers.BanManager;
import com.anticheat.totem.managers.ViolationManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

/**
 * Detecte les patterns d'auto-totem.
 *
 * Principe : quand un totem se declenche (EntityResurrectEvent), un vrai
 * joueur doit soit :
 *   (a) ne plus avoir de totem en offhand tout de suite (il n'en a plus / il
 *       le replace manuellement plus tard), soit
 *   (b) avoir effectue une action manuelle d'inventaire (clic, swap, hotbar)
 *       recente pour expliquer la reapparition d'un nouveau totem.
 *
 * Un auto-totem (module client-side ou plugin serveur triche) reapprovisionne
 * l'offhand quasi instantanement, sans la moindre interaction manuelle, et le
 * fait de facon repetee avec un timing anormalement constant/rapide.
 */
public class AutoTotemListener implements Listener {

    private final AntiCheatTotem plugin;
    private final ViolationManager violationManager;
    private final BanManager banManager;
    private final InteractionTracker interactionTracker;

    public AutoTotemListener(AntiCheatTotem plugin, ViolationManager violationManager,
                              BanManager banManager, InteractionTracker interactionTracker) {
        this.plugin = plugin;
        this.violationManager = violationManager;
        this.banManager = banManager;
        this.interactionTracker = interactionTracker;
    }

    @EventHandler
    public void onResurrect(EntityResurrectEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (player.hasPermission("anticheattotem.bypass")) return;

        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();

        checkReactionTiming(player, uuid, now);

        // On verifie l'etat de l'offhand quelques ticks plus tard,
        // le temps que l'evenement de consommation du totem soit resolu.
        new BukkitRunnable() {
            @Override
            public void run() {
                checkRefillWithoutInteraction(player, uuid, now);
            }
        }.runTaskLater(plugin, 2L);

        violationManager.setLastTotemTimestamp(uuid, now);
    }

    /**
     * Verifie l'intervalle entre deux activations de totem : un humain ne
     * peut pas re-declencher un totem de facon fiable en quelques dizaines
     * de ms de facon repetee.
     */
    private void checkReactionTiming(Player player, UUID uuid, long now) {
        long last = violationManager.getLastTotemTimestamp(uuid);
        if (last == -1) return;

        long minHumanMs = plugin.getConfig().getLong("detection.min-human-reaction-ms", 120);
        long delta = now - last;

        if (delta < minHumanMs) {
            flag(player, uuid, "AutoTotem (timing anormal: " + delta + "ms)");
        }
    }

    /**
     * Verifie si l'offhand a ete reapprovisionne en totem sans la moindre
     * interaction manuelle recente du joueur.
     */
    private void checkRefillWithoutInteraction(Player player, UUID uuid, long resurrectTime) {
        if (!player.isOnline()) return;

        ItemStack offhand = player.getInventory().getItemInOffHand();
        if (offhand == null || offhand.getType() != Material.TOTEM_OF_UNDYING) {
            return; // Pas de nouveau totem, rien de suspect
        }

        long window = plugin.getConfig().getLong("detection.manual-interaction-window-ms", 800);
        long lastInteraction = interactionTracker.getLastInteraction(uuid);

        // Si aucune interaction, ou une interaction bien anterieure a
        // l'evenement (donc qui ne peut pas expliquer le reapprovisionnement)
        boolean noRecentInteraction = lastInteraction == -1
                || lastInteraction < resurrectTime
                || (lastInteraction - resurrectTime) > window;

        if (noRecentInteraction) {
            flag(player, uuid, "AutoTotem (reapprovisionnement sans interaction manuelle)");
        }
    }

    private void flag(Player player, UUID uuid, String detail) {
        int vl = violationManager.addViolation(uuid);
        banManager.alertStaff(player, vl);

        if (plugin.getConfig().getBoolean("log-to-console", true)) {
            plugin.getLogger().info("[DETECTION] " + player.getName() + " - " + detail + " (VL: " + vl + ")");
        }

        int threshold = plugin.getConfig().getInt("detection.violation-threshold", 2);
        if (vl >= threshold) {
            violationManager.clearViolations(uuid);
            banManager.punish(player, "AutoTotem");
        }
    }
}
