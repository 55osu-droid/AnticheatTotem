package com.anticheat.totem.commands;

import com.anticheat.totem.AntiCheatTotem;
import com.anticheat.totem.managers.ViolationManager;
import org.bukkit.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ACTotemCommand implements CommandExecutor, TabCompleter {

    private final AntiCheatTotem plugin;
    private final ViolationManager violationManager;

    public ACTotemCommand(AntiCheatTotem plugin, ViolationManager violationManager) {
        this.plugin = plugin;
        this.violationManager = violationManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("anticheattotem.admin")) {
            sender.sendMessage(ChatColor.RED + "Tu n'as pas la permission.");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(ChatColor.YELLOW + "Usage: /actotem <reload|vl|clear> [joueur]");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage(ChatColor.GREEN + "Configuration AntiCheatTotem rechargee.");
            }
            case "vl" -> {
                if (args.length < 2) {
                    sender.sendMessage(ChatColor.YELLOW + "Liste des violations actives :");
                    for (Map.Entry<UUID, Integer> entry : violationManager.getAllViolations().entrySet()) {
                        OfflinePlayer op = Bukkit.getOfflinePlayer(entry.getKey());
                        sender.sendMessage(ChatColor.GRAY + "- " + op.getName() + ": " + entry.getValue());
                    }
                } else {
                    Player target = Bukkit.getPlayer(args[1]);
                    if (target == null) {
                        sender.sendMessage(ChatColor.RED + "Joueur introuvable ou hors ligne.");
                        return true;
                    }
                    int vl = violationManager.getViolations(target.getUniqueId());
                    sender.sendMessage(ChatColor.YELLOW + target.getName() + " a " + vl + " violation(s).");
                }
            }
            case "clear" -> {
                if (args.length < 2) {
                    sender.sendMessage(ChatColor.RED + "Usage: /actotem clear <joueur>");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(ChatColor.RED + "Joueur introuvable ou hors ligne.");
                    return true;
                }
                violationManager.clearViolations(target.getUniqueId());
                sender.sendMessage(ChatColor.GREEN + "Violations de " + target.getName() + " reinitialisees.");
            }
            default -> sender.sendMessage(ChatColor.YELLOW + "Usage: /actotem <reload|vl|clear> [joueur]");
        }

        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            completions.addAll(List.of("reload", "vl", "clear"));
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("vl") || args[0].equalsIgnoreCase("clear"))) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                completions.add(p.getName());
            }
        }
        return completions;
    }
}
